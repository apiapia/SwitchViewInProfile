//
//  TeacherHomePageMoreView.swift
//  GGSTeacher
//
//  Created by cc mac mini on 16/5/13.
//  Copyright © 2016年 庄宇飞. All rights reserved.
//  Update by 布袋 on 07/25/2017

import UIKit
class TeacherHomePageMoreView: UIView {
    override func awakeFromNib() {
        super.awakeFromNib()
        
    }
}
